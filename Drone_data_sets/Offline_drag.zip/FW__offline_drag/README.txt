Offline drag estimation using optitrack position speed and attitude data.

Flights consist of an optitrack based hover segment and a pitch forward segment.
Pitch angles are 5,10,20 deg


%Example 10 deg
%import optitrack data into struct
flight_10 = import_optitrack_data('2017-01-23 04.50.45 PM_offline_drag_10deg',{'Rigid Body 1'})

%import onboard data into struct
flight_10_OB = import_onboard_data('10deg')

%allignment, still needs checking
[OT_a,OB_a] = align_signals(flight_10,flight_10_OB,'Z')