function OB = import_onboard_data(name)

OB = struct;

%data = csvread(['onboard_log ' name '.csv'],0,0);
data = csvread([ name '.csv'],0,0);
% IMU = struct;
% OTOB = struct;
% BAT = struct;
% COM = struct;
% ACT = struct;
g = 9.8124;
scale_pqr = 0.0139882;   %deg/s
scale_acc = 1/1024/g; %1/1024

S_acc = 4096; % 2048 according to datasheet
S_om = 1879.3; % 16.4 according to datasheet

OB.COUNTER     = data(:,1);
OB.TIME    = data(:,2);
%OB.IMU.TIME    = data(:,2);
OB.IMU.P       = data(:,3) * scale_pqr;
OB.IMU.Q       = data(:,4) * scale_pqr;
OB.IMU.R       = data(:,5) * scale_pqr;
OB.IMU.AX      = data(:,6) * scale_acc;
OB.IMU.AY      = data(:,7) * scale_acc;
OB.IMU.AZ      = data(:,8) * scale_acc;
% OB.IMU.P_UNSCALED = data(:,10) / S_om;
% OB.IMU.Q_UNSCALED = data(:,11) / S_om;
% OB.IMU.R_UNSCALED = data(:,12) / S_om;
% OB.IMU.AX_UNSCALED = data(:,13) / S_acc;
% OB.IMU.AY_UNSCALED = data(:,14) / S_acc;
% OB.IMU.AZ_UNSCALED = data(:,15) / S_acc;
OB.IMU.MAGX    = data(:,9);
OB.IMU.MAGY    = data(:,10);
OB.IMU.MAGZ    = data(:,11);
OB.IMU.PHI     = data(:,12);%*57.3;
OB.IMU.THETA   = data(:,13);%*57.3;
OB.IMU.PSI     = data(:,14);%*57.3;

OB.OTOB.PosNED = data(:,15:17);
OB.OTOB.VelNED = data(:,18:20);

OB.COM.THRUST = data(:,21);
OB.COM.PHI = data(:,22);
OB.COM.THETA = data(:,23);
OB.COM.PSI = data(:,24);
OB.BAT.VOLTAGE = data(:,25);
OB.BAT.CURRENT = data(:,26);
OB.COM.RPM1 = data(:,27);
OB.COM.RPM2 = data(:,28);
OB.COM.RPM3 = data(:,29);
OB.COM.RPM4 = data(:,30);

OB.ACT.RPM1 = data(:,31);
OB.ACT.RPM2 = data(:,32);
OB.ACT.RPM3 = data(:,33);
OB.ACT.RPM4 = data(:,34);
end