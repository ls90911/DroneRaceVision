function [OT_a,OB_a] = align_signals(OT,OB,method)

switch method
    case 'phi'
        [s1,s2,Delay] = alignsignals(OB.IMU.PHI,OT.PHI); % using phi signal temporary
    case 'Z'
        [s1,s2,Delay] = alignsignals(OB.OTOB.PosNED(:,3),-OT.posCO_G(:,2)-(-OT.posCO_G(1,2)-OB.OTOB.PosNED(1,3))); %using height
    case 'Z_top' %Use the upper 20% height to align signals
        hthr = min(OB.OTOB.PosNED(:,3))*0.8;
        h1 = find(OB.OTOB.PosNED(:,3)<=hthr); h2 = find(-OT.posCO_G(:,2)-(-OT.posCO_G(1,2)-OB.OTOB.PosNED(1,3))<=hthr);
        hh1 = -0*ones(size(OB.OTOB.PosNED(:,3))); hh2 = -0*ones(size(-OT.posCO_G(:,2)));
        hh1(h1) = OB.OTOB.PosNED(h1,3); hh2(h2) = -OT.posCO_G(h2,2)-(-OT.posCO_G(1,2)-OB.OTOB.PosNED(1,3));
        [s1,s2,Delay] = alignsignals(-hh1,-hh2);
    case 'VZ'
        [s1,s2,Delay] = alignsignals(OB.OTOB.VelNED(:,3),OT.vel_E(:,3)); %using Vz 
end

L_OB = length(OB.TIME);
L_OT  = length(OT.TIME);
if Delay >= 0
    L_SYN = min(L_OT-Delay,L_OB);
    TIME_SYN    = OB.TIME(1:L_SYN);
    P_syn_D     = OB.IMU.P(1:L_SYN);
    Q_syn_D     = OB.IMU.Q(1:L_SYN);
    R_syn_D     = OB.IMU.R(1:L_SYN);
    AX_syn_D    = OB.IMU.AX(1:L_SYN);
    AY_syn_D    = OB.IMU.AY(1:L_SYN);
    AZ_syn_D    = OB.IMU.AZ(1:L_SYN);
    RPM1        = OB.ACT.RPM1(1:L_SYN);
    RPM2        = OB.ACT.RPM2(1:L_SYN);
    RPM3        = OB.ACT.RPM3(1:L_SYN);
    RPM4        = OB.ACT.RPM4(1:L_SYN);
    PHI_int     = OB.IMU.PHI(1:L_SYN);
    THETA_int   = OB.IMU.THETA(1:L_SYN);
    PSI_int     = OB.IMU.PSI(1:L_SYN);
    PosNED_syn_D = OB.OTOB.PosNED(1:L_SYN,:);
    
    PHI_syn_D = OT.PHI(Delay+1:Delay+L_SYN);
    THETA_syn_D = OT.THETA(Delay+1:Delay+L_SYN);
    PSI_syn_D = OT.PSI(Delay+1:Delay+L_SYN);
    Pos_syn_D   = OT.posCG_E(Delay+1:Delay+L_SYN,:);
    Vx_syn_D    = OT.VX(Delay+1:Delay+L_SYN);
    Vy_syn_D    = OT.VY(Delay+1:Delay+L_SYN);
    Vz_syn_D    = OT.VZ(Delay+1:Delay+L_SYN);
    AxOT        = OT.accCG_B(Delay+1:Delay+L_SYN,1);
    AyOT        = OT.accCG_B(Delay+1:Delay+L_SYN,2);
    AzOT        = OT.accCG_B(Delay+1:Delay+L_SYN,3);
    velCG_B_syn_D = OT.velCG_B(Delay+1:Delay+L_SYN,:);    
    Acc_B_syn_D   = OT.acc_B(Delay+1:Delay+L_SYN,:); 
    posCO_G_syn_D = OT.posCO_G(Delay+1:Delay+L_SYN,:);      
else
    L_SYN = min(L_OT,L_OB+Delay);
    TIME_SYN    = OB.TIME(1-Delay:L_SYN-Delay);
    P_syn_D     = OB.IMU.P(1-Delay:L_SYN-Delay);
    Q_syn_D     = OB.IMU.Q(1-Delay:L_SYN-Delay);
    R_syn_D     = OB.IMU.R(1-Delay:L_SYN-Delay);
    AX_syn_D    = OB.IMU.AX(1-Delay:L_SYN-Delay);
    AY_syn_D    = OB.IMU.AY(1-Delay:L_SYN-Delay);
    AZ_syn_D    = OB.IMU.AZ(1-Delay:L_SYN-Delay);
    RPM1        = OB.ACT.RPM1(1-Delay:L_SYN-Delay);
    RPM2        = OB.ACT.RPM2(1-Delay:L_SYN-Delay);
    RPM3        = OB.ACT.RPM3(1-Delay:L_SYN-Delay);
    RPM4        = OB.ACT.RPM4(1-Delay:L_SYN-Delay);    
    PHI_int     = OB.IMU.PHI(1-Delay:L_SYN-Delay);
    THETA_int   = OB.IMU.THETA(1-Delay:L_SYN-Delay);
    PSI_int     = OB.IMU.PSI(1-Delay:L_SYN-Delay);
    PosNED_syn_D = OB.OTOB.PosNED(1-Delay:L_SYN-Delay,:);
    
    PHI_syn_D = OT.PHI(1:L_SYN);
    THETA_syn_D = OT.THETA(1:L_SYN);
    PSI_syn_D = OT.PSI(1:L_SYN);
    Pos_syn_D   = OT.posCG_E(1:L_SYN,:);
    Vx_syn_D    = OT.VX(1:L_SYN);
    Vy_syn_D    = OT.VY(1:L_SYN);
    Vz_syn_D    = OT.VZ(1:L_SYN);
    AxOT        = OT.accCG_B(1:L_SYN,1);
    AyOT        = OT.accCG_B(1:L_SYN,2);
    AzOT        = OT.accCG_B(1:L_SYN,3);
    velCG_B_syn_D = OT.velCG_B(1:L_SYN,:);
    Acc_B_syn_D   = OT.acc_B(1:L_SYN,:);
    posCO_G_syn_D = OT.posCO_G(1:L_SYN,:);   
end
% TIME_SYN =  [0:dTIME_SYN:dTIME_SYN*(L_SYN-1)]';

OB_a.TIME  = TIME_SYN;
OB_a.IMU.TIME  = TIME_SYN;
OB_a.IMU.P     = P_syn_D;
OB_a.IMU.Q     = Q_syn_D;
OB_a.IMU.R     = R_syn_D;
OB_a.IMU.AX    = AX_syn_D;
OB_a.IMU.AY    = AY_syn_D;
OB_a.IMU.AZ    = AZ_syn_D;
OB_a.ACT.RPM1  = RPM1;
OB_a.ACT.RPM2  = RPM2;
OB_a.ACT.RPM3  = RPM3;
OB_a.ACT.RPM4  = RPM4;
OB_a.IMU.PHI   = PHI_int;
OB_a.IMU.THETA   = THETA_int;
OB_a.IMU.PSI   = PSI_int;
OB_a.OTOB.PosNED = PosNED_syn_D;

OT_a.TIME          = TIME_SYN;
OT_a.posCG_E  = Pos_syn_D;
OT_a.X             = Pos_syn_D(:,1);
OT_a.Y             = Pos_syn_D(:,2);
OT_a.Z             = Pos_syn_D(:,3);
OT_a.velCG_E(:,1) = Vx_syn_D;
OT_a.velCG_E(:,2) = Vy_syn_D;
OT_a.velCG_E(:,3) = Vz_syn_D;
OT_a.VX            = Vx_syn_D;
OT_a.VY            = Vy_syn_D;
OT_a.VZ            = Vz_syn_D;
OT_a.PHI           = PHI_syn_D;
OT_a.THETA         = THETA_syn_D;
OT_a.PSI           = PSI_syn_D;
OT_a.accCG_B(:,1) = AxOT;
OT_a.accCG_B(:,2) = AyOT;
OT_a.accCG_B(:,3) = AzOT;
OT_a.AX = AxOT;
OT_a.AY = AyOT;
OT_a.AZ = AzOT;
OT_a.velCG_B     = velCG_B_syn_D;
OT_a.U           = velCG_B_syn_D(:,1);
OT_a.V           = velCG_B_syn_D(:,2);
OT_a.W           = velCG_B_syn_D(:,3);
OT_a.acc_B         = Acc_B_syn_D;
OT_a.posCO_G     = posCO_G_syn_D;

% Check align result
% figure('position',[0 0,700,200])
% plot(OB_a.OTOB.PosNED(:,3)); hold on
% plot(-OT_a.posCO_G(:,2)-(-OT_a.posCO_G(1,2)-OB_a.OTOB.PosNED(1,3))); ylabel(method);title('Check alignment');
end